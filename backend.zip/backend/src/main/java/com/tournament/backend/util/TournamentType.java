package com.tournament.backend.util;

public enum TournamentType {
    ROUND_ROBIN,
    KNOCKOUT
}
